package controllers

import (
	// "bookc/models"
	"net/http"

	"gin.com/gin/models"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

type CreateTaskInput struct {
	StudentName   string `json:"studentname"`
	StudentAge    int64  `json:"age"`
	StudentGender string `json:"gender"`
	StudentDiv    string `json:"div"`
}

type UpdateTaskInput struct {
	StudentName   string `json:"studentname"`
	StudentAge    int64  `json:"age"`
	StudentGender string `json:"gender"`
	StudentDiv    string `json:"div"`
}

// GET /tasks
// Get all tasks
func FindTasks(c *gin.Context) {
	db := c.MustGet("db").(*gorm.DB)
	var students []models.Student
	db.Find(&students)

	c.JSON(http.StatusOK, gin.H{"data": students})
}

// POST /tasks
// Create new task
func CreateTask(c *gin.Context) {
	// Validate input
	var input CreateTaskInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Create task
	student := models.Student{StudentName: input.StudentName, StudentAge: input.StudentAge, StudentGender: input.StudentGender, StudentDiv: input.StudentDiv}

	db := c.MustGet("db").(*gorm.DB)
	db.Create(&student)

	c.JSON(http.StatusOK, gin.H{"data": student})
}

// GET /tasks/:id
// Find a task
func FindTask(c *gin.Context) { // Get model if exist
	var student models.Student

	db := c.MustGet("db").(*gorm.DB)
	if err := db.Where("id = ?", c.Param("id")).First(&student).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Record not found!"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": student})
}

// PATCH /tasks/:id
// Update a task
func UpdateTask(c *gin.Context) {

	db := c.MustGet("db").(*gorm.DB)
	// Get model if exist
	var student models.Student
	if err := db.Where("id = ?", c.Param("id")).First(&student).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Record not found!"})
		return
	}

	// Validate input
	var input UpdateTaskInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var updatedInput models.Student
	updatedInput.StudentName = input.StudentName
	updatedInput.StudentAge = input.StudentAge
	updatedInput.StudentGender = input.StudentGender
	updatedInput.StudentDiv = input.StudentDiv

	db.Model(&student).Updates(updatedInput)

	c.JSON(http.StatusOK, gin.H{"data": student})
}

// DELETE /tasks/:id
// Delete a task
func DeleteTask(c *gin.Context) {
	// Get model if exist
	db := c.MustGet("db").(*gorm.DB)
	var student models.Student
	if err := db.Where("id = ?", c.Param("id")).First(&student).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Record not found!"})
		return
	}

	db.Delete(&student)

	c.JSON(http.StatusOK, gin.H{"data": true})
}

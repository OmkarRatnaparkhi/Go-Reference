package routes

import (
	"gin.com/gin/controllers"

	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

func SetupRoutes(db *gorm.DB) *gin.Engine {
	r := gin.Default()
	r.Use(func(c *gin.Context) {
		c.Set("db", db)
	})
	r.GET("/students", controllers.FindTasks)
	r.POST("/students", controllers.CreateTask)
	r.GET("/students/:id", controllers.FindTask)
	r.PATCH("/students/:id", controllers.UpdateTask)
	r.DELETE("students/:id", controllers.DeleteTask)
	return r
}

package main

import(
	"context"
	"github.com/go-redis/redis/v8"
	"fmt"
)

var ctx = context.Background()

func main(){
	rdb := redis.NewClient(&redis.Options{
		Addr: "127.0.0.1:6379",
		Password: "",
		DB: 0,
	})
/*	
	// Setting and getting data in redis using Primitive data type (String)
	err := rdb.Set(ctx, "key", "value", 0).Err()
	if err != nil {
		panic(err)
	}
	
	val, err := rdb.Get(ctx, "key").Result()
	if err != nil {
		panic(err)
	}
	fmt.Println("key", val)
	
	val2, err := rdb.Get(ctx, "key").Result()
	if err == redis.Nil {
		fmt.Println("key2 does not exist")
	} else if err != nil {
		panic(err)
	} else {
		fmt.Println("key2",val2)
	}
*/	

	err := rdb.Set(ctx, "name", "Omkar Ratnaparkhi",0).Err()
	if err != nil {
		panic(err)
	}
	
	val, err := rdb.Get(ctx, "name").Result()
	if err != nil {
		panic(err)
	}
	fmt.Println("name",val)

	err2 := rdb.Set(ctx, "name1", "Kedar Mali",0).Err()
	if err != nil {
		panic(err2)
	}
	
	val2, err2 := rdb.Get(ctx, "name1").Result()
	if err2 == redis.Nil{
		fmt.Println("name1 does not exist")
	} else if err2 != nil {
		panic(err2)
	} else {
		fmt.Println("name1", val2)
	}

}
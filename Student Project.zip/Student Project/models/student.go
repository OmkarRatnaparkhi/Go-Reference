package models

type Student struct {
	ID            uint   `json:"id" gorm:"primary_key"`
	StudentName   string `json:"studentname"`
	StudentAge    int64  `json:"age"`
	StudentGender string `json:"gender"`
	StudentDiv    string `json:"div"`
}

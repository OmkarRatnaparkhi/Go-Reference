package controllers

import (
	"net/http"

	"gin.com/gin/models" //Error: import cycle not allowed
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
	"github.com/microcosm-cc/bluemonday"
)

type CreateStudentInput struct {
	StudentName   string `json:"studentname"`
	StudentAge    int64  `json:"age"`
	StudentGender string `json:"gender"`
	StudentDiv    string `json:"div"`
}

type UpdateStudentInput struct {
	StudentName   string `json:"studentname"`
	StudentAge    int64  `json:"age"`
	StudentGender string `json:"gender"`
	StudentDiv    string `json:"div"`
}

// GET /students
// Get all students
func FindStudents(c *gin.Context) {
	//	r := gin.Default()

	//	r.Use(routes.Cors())

	db := c.MustGet("db").(*gorm.DB)
	var students []models.Student
	db.Find(&students)

	c.JSON(http.StatusOK, gin.H{"data": students}) //c.JSON(http.StatusOK, students)
}

// Create new students
// func CreateStudent(c *gin.Context) {
// 	// Validate input
// 	var input CreateStudentInput
// 	if err := c.ShouldBindJSON(&input); err != nil {
// 		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
// 		return
// 	}

// 	// Create students
// 	student := models.Student{
// 		StudentName:   input.StudentName,
// 		StudentAge:    input.StudentAge,
// 		StudentGender: input.StudentGender,
// 		StudentDiv:    input.StudentDiv,
// 	}

// 	db := c.MustGet("db").(*gorm.DB)
// 	db.Create(&student)

// 	c.JSON(http.StatusOK, gin.H{"data": student})
// }
func CreateStudent(c *gin.Context) {
	// Validate input
	var input CreateStudentInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Sanitize user inputs using bluemonday
	p := bluemonday.UGCPolicy() // Create a bluemonday policy

	// Create students
	student := models.Student{
		StudentName:   p.Sanitize(input.StudentName),
		StudentAge:    input.StudentAge,
		StudentGender: input.StudentGender,
		StudentDiv:    input.StudentDiv,
	}

	db := c.MustGet("db").(*gorm.DB)
	db.Create(&student)

	c.JSON(http.StatusOK, gin.H{"data": student})
}

// GET /students/:id
// Find a students
func FindStudent(c *gin.Context) { // Get model if exist
	var student models.Student

	db := c.MustGet("db").(*gorm.DB)
	if err := db.Where("id = ?", c.Param("id")).First(&student).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Record not found!"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"data": student}) //c.JSON(http.StatusOK, students)
}

// PATCH /students/:id
// Update a students
func UpdateStudent(c *gin.Context) {

	db := c.MustGet("db").(*gorm.DB)
	// Get model if exist
	var student models.Student
	if err := db.Where("id = ?", c.Param("id")).First(&student).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Record not found!"})
		return
	}

	// Validate input
	var input UpdateStudentInput
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	var updatedInput models.Student
	updatedInput.StudentName = input.StudentName
	updatedInput.StudentAge = input.StudentAge
	updatedInput.StudentGender = input.StudentGender
	updatedInput.StudentDiv = input.StudentDiv

	db.Model(&student).Updates(updatedInput)

	c.JSON(http.StatusOK, gin.H{"data": student})
}

// DELETE /students/:id
// Delete a students
func DeleteStudent(c *gin.Context) {
	// Get model if exist
	db := c.MustGet("db").(*gorm.DB)
	var student models.Student
	if err := db.Where("id = ?", c.Param("id")).First(&student).Error; err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Record not found!"})
		return
	}

	db.Delete(&student)

	c.JSON(http.StatusOK, gin.H{"data": true})
}

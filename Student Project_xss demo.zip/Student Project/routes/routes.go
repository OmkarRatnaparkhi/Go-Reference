package routes

import (
	"net/http"

	"gin.com/gin/controllers"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/gorm"
)

func Cors() gin.HandlerFunc {
	return func(c *gin.Context) {
		method := c.Request.Method
		//if origin != "" {
		//You can replace * with the specified domain name
		c.Header("Access-Control-Allow-Origin", "*")
		c.Header("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PATCH, DELETE, UPDATE")
		c.Header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization")
		c.Header("Access-Control-Expose-Headers", "Content-Length, Access-Control-Allow-Origin, Access-Control-Allow-Headers, Cache-Control, Content-Language, Content-Type")
		c.Header("Access-Control-Allow-Credentials", "true")
		//}

		if method == "OPTIONS" {
			c.AbortWithStatus(http.StatusNoContent)
		}

		c.Next()
	}
}

func SetupRoutes(db *gorm.DB) *gin.Engine {
	r := gin.Default()

	r.Use(Cors())

	r.Use(func(c *gin.Context) {
		c.Set("db", db)
	})
	r.GET("/students", controllers.FindStudents)
	r.POST("/students/create-student", controllers.CreateStudent)
	r.GET("/students/get-student/:id", controllers.FindStudent)
	r.PATCH("/students/update-student/:id", controllers.UpdateStudent)
	r.DELETE("/students/delete-student/:id", controllers.DeleteStudent)
	return r
}

//r.GET("/get-all-students", controllers.FindStudents)			/students
//r.POST("/create-students", controllers.CreateStudent)			/students/create-student
//r.GET("/get-student/:id", controllers.FindStudent)			/students/get-student/:id
//r.PATCH("/update-student/:id", controllers.UpdateStudent)		/students/update-student/:id
//r.DELETE("/delete-student/:id", controllers.DeleteStudent)	/students/delete-student/:id
